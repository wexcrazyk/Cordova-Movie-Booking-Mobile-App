<?php
    include 'db.php';
    $username = $_GET['username'];
    $password = $_GET['password'];
    
    $sql = "SELECT username,password FROM user where username = '$username' and password = '$password'";
    $result = mysqli_query($con, $sql);
    
        while($row = mysqli_fetch_object($result)) {
            $data[]= $row;
        }
        echo json_encode($data);
?>