<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","root","root","cinema") or die ("could not connect database");
?>	