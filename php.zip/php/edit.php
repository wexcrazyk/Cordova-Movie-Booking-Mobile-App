<?php
 header("Access-Control-Allow-Origin: *");
 header("Access-Control-Allow-Methods: POST");

 include "db.php";
    
    $user = $_POST['username'];
 	$pass = $_POST['password'];
	$nama = $_POST['nama'];
	$phone	=	$_POST['phone'];
	 
	$q=mysqli_query($con,"UPDATE user SET password = '$pass', nama = '$nama', phone = '$phone' WHERE username = '$user' ");
	

		if($q)
			{echo "success";}
		else
			{echo "error";}
 ?>