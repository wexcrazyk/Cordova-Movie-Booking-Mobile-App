<?php
 include "db.php";

 	$sql = "SET @autoid :=0";
	$result = mysqli_query($con, $sql);
	$sql = "UPDATE user SET id = @autoid := (@autoid+1)";
	$result = mysqli_query($con, $sql);
	$sql = "ALTER TABLE user AUTO_INCREMENT=1";
	$result = mysqli_query($con, $sql);
   
    $username=$_GET['username'];

    $sql = "SELECT * FROM user WHERE username ='$username'";
    $result = mysqli_query($con, $sql);
    
        while($row = mysqli_fetch_object($result)) {
            $data[]= $row;
        }
        
        echo json_encode($data);
    
 ?>