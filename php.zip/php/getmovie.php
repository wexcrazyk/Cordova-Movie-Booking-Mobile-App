<?php
 include "db.php";
   
    $movid=$_GET['movid'];

    $sql = "SELECT movieImg FROM movie WHERE movieid ='$movid'";
    $result = mysqli_query($con, $sql);
    
        while($row = mysqli_fetch_object($result)) {
            $data[]= $row;
        }
        
        echo json_encode($data);
    
 ?>