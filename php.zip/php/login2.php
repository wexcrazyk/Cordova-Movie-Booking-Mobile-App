<?php
session_start();

$errors = array();
$db = mysqli_connect('localhost', 'root', 'root', 'cinema') or die($db);

//login
// $email = mysqli_real_escape_string($db,$_POST['email']);
// $password = mysqli_real_escape_string($db,$_POST['password']);

$email = $_POST['email'];
$password = $_POST['password'];
    if(count($errors) == 0 ){
        $get_user_id = "SELECT id FROM user WHERE nama='$email'";
        $res_id = $db->query($get_user_id);
        $user_id = $res_id->fetch_array()[0] ?? '';

        $q = "SELECT * FROM user WHERE nama='$email' AND password='$password'";
        $result = mysqli_query($db, $q);
        $count = mysqli_num_rows($result);

        if($count == 1) {
            $_SESSION['logged_in'] = true;
            $_SESSION['id'] = $user_id;   
            echo 1; //login   
        }
        else{
            echo 0; //error login
        }
    }
?>