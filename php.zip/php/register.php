<?php
 header("Access-Control-Allow-Origin: *");
 header("Access-Control-Allow-Methods: POST");

 include "db.php";
 
	$username	=	$_POST['username'];
	$password = $_POST['password']; 
	$nama	=	$_POST['nama'];
	$phone    =   $_POST['phone'];
	
	$q=mysqli_query($con,"INSERT INTO user(username,password,nama,phone) VALUES('$username','$password','$nama', '$phone')");
	

		if($q)
			{echo "success";}
		else
			{echo "error";}
 ?>