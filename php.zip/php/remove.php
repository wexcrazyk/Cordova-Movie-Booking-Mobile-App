<?php
 include "db.php";
   $username = $_POST['username'];

    $sql = "DELETE FROM user WHERE username = '$username' ";
    $result = mysqli_query($con, $sql);

    if($result){
        echo "success";
    }else{
    echo "error";
    }
    
 ?>