<?php
 header("Access-Control-Allow-Origin: *");
 header("Access-Control-Allow-Methods: POST");

 include "db.php";

 // 	$q = "SET @autoid :=0";
	// $q = "UPDATE booking SET id = @autoid := (@autoid+1)";
	// $q = "ALTER TABLE booking AUTO_INCREMENT=1";

	
 	$movid = $_POST['movieid'];
	$username = $_POST['username'];
	$cinema	=	$_POST['cinema'];
	$movie = $_POST['movie']; 
	$studio	=	$_POST['studio'];
	$date    =   $_POST['datepicker_1'];
	$jam    =   $_POST['jam'];
	 
	$q=mysqli_query($con,"INSERT INTO booking(movieid,username,cinema,movie,studio,datepicker_1,jam) VALUES('$movid','$username','$cinema','$movie','$studio', '$date', '$jam')");
	

		if($q)
			{echo "success";}
		else
			{echo "error";}
 ?>